# AI Code Generator (Flask + Groq)

## Overview
AI Code Generator is a Flask-based web application that allows users to generate optimized and structured code using AI. The system integrates the Groq API with the Llama 3.3-70B model to provide fast and high-quality code generation across multiple programming languages.

The application also includes security features such as rate limiting and input validation to ensure safe and controlled usage.

---

## Features

### AI-Powered Code Generation
- Generates clean, optimized, and structured code
- Provides explanation, full code, and usage instructions

### Multi-Language Support
- Python
- JavaScript
- C++
- Java
- SQL
- General programming queries

### High-Speed AI Inference
- Uses Groq LPU-based inference for ultra-fast responses
- Low latency output generation

### Input Validation
- Prevents empty prompts
- Limits maximum prompt length
- Validates selected programming language

### Rate Limiting (Security)
- Maximum 10 requests per IP per minute
- Prevents abuse and server overload

### REST API System
- JSON-based request and response handling
- Structured API endpoints for frontend integration

---

## Tech Stack

### Backend
- Python 3.x
- Flask (Web Framework)

### AI Engine
- Groq API
- Llama 3.3-70B Versatile Model

### Frontend
- HTML5
- CSS3
- JavaScript (Fetch API)

### Utilities
- python-dotenv (Environment Variables)
- collections (defaultdict for rate limiting)
- time module (request tracking)

---

## Languages Supported
- Python
- JavaScript
- C++
- Java
- SQL
- General (Fallback Mode)

---

## Project Structure

CodeAssistant/
├── app.py              # Main Flask backend (API + logic)
├── .env                # API keys and environment variables
├── requirements.txt    # Python dependencies
└── templates/
    └── index.html      # Frontend UI

---

## Installation & Setup

### 1. Clone Repository
git clone <[repository-url](https://github.com/Sairahanjra002/ARTIFICAL-INTELLIGENCE-LAB-121)>
cd CodeAssistant

### 2. Install Dependencies
pip install -r requirements.txt

### 3. Setup Environment Variables
Create a .env file in root directory:
GROQ_API_KEY=your_api_key_here

### 4. Run Application
python app.py

### 5. Open in Browser
http://127.0.0.1:5000

---

## API Endpoints

### Home Route
GET /

Loads the main dashboard UI.

---

### Generate Code
POST /generate

Request:
{
  "prompt": "write a python function for factorial",
  "language": "Python"
}

Response:
{
  "solution": "generated code with explanation",
  "tokens": 150,
  "language": "Python"
}

---

### Health Check
GET /health

Response:
{
  "status": "ok",
  "model": "llama-3.3-70b-versatile",
  "api_key_set": true
}

---

## Key Concepts Used

- Flask Routing and API Development
- RESTful API Design
- AI Prompt Engineering
- Rate Limiting using IP tracking
- Input Validation and Sanitization
- Exception Handling (Try-Except Blocks)
- Environment Variable Security
- JSON Request/Response Handling

---

## Security Features

- API key stored in environment variables
- Rate limiting to prevent spam requests
- Input validation before AI processing
- Error handling to avoid system crash

---

## Disclaimer
This project is built for educational and development purposes. Generated code should be reviewed before using in production environments.

---

## Author
AI Code Generator Project (Flask + Groq Integration)