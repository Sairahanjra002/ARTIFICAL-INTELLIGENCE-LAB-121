import os
import time
from collections import defaultdict
from flask import Flask, render_template, request, jsonify
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

RATE_LIMIT = 10
RATE_WINDOW = 60 
request_log = defaultdict(list)

def is_rate_limited(ip):
    now = time.time()
   
    request_log[ip] = [t for t in request_log[ip] if now - t < RATE_WINDOW]
    if len(request_log[ip]) >= RATE_LIMIT:
        return True
    request_log[ip].append(now)
    return False


ALLOWED_LANGUAGES = {"Python", "JavaScript", "C++", "SQL", "Java", "General"}
MAX_PROMPT_LENGTH = 1000  

def validate_input(prompt, language):
    if not prompt or not prompt.strip():
        return "Prompt cannot be empty."
    if len(prompt) > MAX_PROMPT_LENGTH:
        return f"Prompt is too long. Maximum {MAX_PROMPT_LENGTH} characters are allowed."
    if language not in ALLOWED_LANGUAGES:
        return "Invalid language selected."
    return None  


@app.route('/')
def index():
    """Renders the main dashboard."""
    return render_template('index.html')


@app.route('/generate', methods=['POST'])
def generate_code():
    """Handles AI code generation with rate limiting and validation."""

   
    user_ip = request.remote_addr
    if is_rate_limited(user_ip):
        return jsonify({
            "error": "Too many requests. Please wait a minute before trying again."
        }), 429

  
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid JSON request."}), 400

    user_prompt = data.get('prompt', '').strip()
    language = data.get('language', 'General').strip()

   
    error = validate_input(user_prompt, language)
    if error:
        return jsonify({"error": error}), 400

    try:
        completion = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {
                    "role": "system",
                    "content": (
                        f"You are an expert {language} developer. "
                        f"Provide clean, efficient, and well-commented {language} code. "
                        "Structure your response as:\n"
                        "1. A brief explanation of your approach (2-3 lines)\n"
                        "2. The complete code\n"
                        "3. A short note on how to run or use it.\n"
                        "Do not include unnecessary filler text."
                    )
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            temperature=0.3,
            max_tokens=2048,
            top_p=1,
            stream=False,
        )

        solution = completion.choices[0].message.content
        tokens_used = completion.usage.total_tokens 

        return jsonify({
            "solution": solution,
            "tokens": tokens_used,
            "language": language
        })

    except Exception as e:
        print(f"[ERROR] Groq API failed: {e}")
        return jsonify({
            "error": "AI engine connection failed. Please check your API key or try again later."
        }), 500



@app.route('/health')
def health():
    """Simple health check — useful for debugging."""
    return jsonify({
        "status": "ok",
        "model": "llama-3.3-70b-versatile",
        "api_key_set": bool(os.getenv("GROQ_API_KEY"))
    })


if __name__ == '__main__':
    app.run(debug=True)
